import React from 'react'
import '../../../styles/Fonts.scss'
import '../../../styles/HTMLControls.scss'
import "../SMLTextArea/SMLTextArea.css"

const SMLTextArea = (props) => {
    return (
        <textarea className="SMLTextarea" placeholder="..."></textarea>
    )
}

export default SMLTextArea
