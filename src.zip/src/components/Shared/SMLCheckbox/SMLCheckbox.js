import React from 'react'
import '../../../styles/Fonts.scss'
import '../../../styles/HTMLControls.scss'

const SMLCheckbox = () => {
  return (
    <div>
      <input type='checkbox' className='SMLCheckbox' />
    </div>
  )
}

export default SMLCheckbox
